package com.baseball.game.mapper;

import com.baseball.game.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    void insertUser(UserDto user);
}
