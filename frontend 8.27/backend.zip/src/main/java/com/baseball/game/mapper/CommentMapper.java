package com.baseball.game.mapper;

import com.baseball.game.dto.CommentDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface CommentMapper {

    int insertComment(CommentDto comment);

    List<CommentDto> getCommentsByPostId(@Param("postId") int postId);

    int deleteComment(@Param("commentId") int commentId);
}
