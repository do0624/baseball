package com.baseball.game.controller;

import com.baseball.game.dto.MemberDto;
import com.baseball.game.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/member")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody MemberDto member) {
        Map<String, Object> res = new HashMap<>();
        try {
            memberService.register(member);
            res.put("success", true);
            res.put("message", "회원가입 성공");
        } catch (IllegalArgumentException e) {
            res.put("success", false);
            res.put("message", e.getMessage());
        } catch (Exception e) {
            res.put("success", false);
            res.put("message", "서버 오류");
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> loginData) {
        String id = loginData.get("id");
        String pw = loginData.get("pw");
        Map<String, Object> res = new HashMap<>();
        if (memberService.checkLogin(id, pw)) {
            res.put("success", true);
            res.put("name", memberService.getUserNameById(id));
        } else {
            res.put("success", false);
            res.put("message", "아이디 또는 비밀번호가 일치하지 않습니다.");
        }
        return ResponseEntity.ok(res);
    }
}
