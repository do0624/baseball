package com.baseball.game.service;

import com.baseball.game.dto.PostDto;
import com.baseball.game.mapper.PostMapper;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Service
public class PostService {

    private final PostMapper postMapper;

    public PostService(PostMapper postMapper) {
        this.postMapper = postMapper;
    }

    public Map<String, Object> getPosts(String category, String keyword, int page, int size) {
    	int offset = Math.max(0, (page - 1) * size);
        List<PostDto> content = postMapper.getPosts(category, keyword, offset, size);
        int total = postMapper.countPosts(category, keyword);
        int totalPages = (int) Math.ceil(total / (double) size);

        Map<String, Object> result = new HashMap<>();
        result.put("content", content);
        result.put("totalPages", totalPages);
        return result;
    }

    public PostDto getPost(int postId) {
        return postMapper.getPostById(postId);
    }

    public void createPost(PostDto post) {
        postMapper.insertPost(post);
    }

    public void updatePost(PostDto post) {
        postMapper.updatePost(post);
    }

    public void deletePost(int postId) {
        postMapper.deletePost(postId);
    }
}
