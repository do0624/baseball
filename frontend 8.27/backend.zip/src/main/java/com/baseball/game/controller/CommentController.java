package com.baseball.game.controller;

import com.baseball.game.dto.CommentDto;
import com.baseball.game.service.CommentService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    // 특정 게시글 댓글 조회
    @GetMapping("/{postId}")
    public List<CommentDto> getComments(@PathVariable("postId") int postId) {
        return commentService.getCommentsByPostId(postId);
    }

    // 댓글 작성
    @PostMapping
    public void createComment(@RequestBody CommentDto comment) {
        commentService.createComment(comment);
    }

    // 댓글 삭제
    @DeleteMapping("/{commentId}")
    public void deleteComment(@PathVariable("commentId") int commentId) {
        commentService.deleteComment(commentId);
    }
}
