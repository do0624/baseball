package com.baseball.game.controller;

import com.baseball.game.service.PostService;
import com.baseball.game.dto.PostDto;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/board")
@CrossOrigin(origins = "http://localhost:3000")  // React 개발 서버 허용
public class BoardController {

    private final PostService postService;

    public BoardController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public Map<String, Object> getPosts(
            @RequestParam(defaultValue = "all") String category,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        return postService.getPosts(category, keyword, page, size);
    }
}
