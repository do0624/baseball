package com.baseball.game.service;

import com.baseball.game.dto.MemberDto;
import com.baseball.game.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberMapper memberMapper;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public MemberDto register(MemberDto memberDto) throws Exception {
        if (memberMapper.checkIdExists(memberDto.getId()) > 0) {
            throw new IllegalArgumentException("이미 존재하는 아이디입니다.");
        }
        memberDto.setPw(passwordEncoder.encode(memberDto.getPw()));
        memberMapper.insertMember(memberDto);
        return memberDto;
    }

    @Override
    public boolean checkLogin(String id, String pw) {
        String hashedPw = memberMapper.selectPwById(id);
        return hashedPw != null && passwordEncoder.matches(pw, hashedPw);
    }

    @Override
    public String getUserNameById(String id) {
        return memberMapper.selectUserNameById(id);
    }
}
