package com.baseball.game.dto;

public class MemberDto {
    private String id;
    private String username;
    private String pw;
    private String email;
    private String team;
    private int game;
    private int win;
    private int lose;
    private int draw;

    public MemberDto() {}

    // getter / setter
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPw() { return pw; }
    public void setPw(String pw) { this.pw = pw; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
    public int getGame() { return game; }
    public void setGame(int game) { this.game = game; }
    public int getWin() { return win; }
    public void setWin(int win) { this.win = win; }
    public int getLose() { return lose; }
    public void setLose(int lose) { this.lose = lose; }
    public int getDraw() { return draw; }
    public void setDraw(int draw) { this.draw = draw; }
}
