package com.baseball.game.mapper;

import com.baseball.game.dto.PostDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PostMapper {

    void insertPost(PostDto post);

    PostDto getPostById(@Param("postId") int postId);

    List<PostDto> getPosts(
        @Param("category") String category,
        @Param("keyword") String keyword,
        @Param("offset") int offset,
        @Param("size") int size
    );

    int countPosts(
        @Param("category") String category,
        @Param("keyword") String keyword
    );

    void updatePost(PostDto post);

    void deletePost(@Param("postId") int postId);
}
