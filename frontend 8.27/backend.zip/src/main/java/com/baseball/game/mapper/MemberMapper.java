package com.baseball.game.mapper;

import com.baseball.game.dto.MemberDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MemberMapper {

    @Insert("INSERT INTO member (id, pw, username, email, team, game, win, lose, draw) " +
            "VALUES (#{id}, #{pw}, #{username}, #{email}, #{team}, #{game}, #{win}, #{lose}, #{draw})")
    void insertMember(MemberDto member);

    @Select("SELECT COUNT(*) FROM member WHERE id = #{id}")
    int checkIdExists(String id);

    @Select("SELECT pw FROM member WHERE id = #{id}")
    String selectPwById(String id);

    @Select("SELECT username FROM member WHERE id = #{id}")
    String selectUserNameById(String id);
}