package com.baseball.game.service;

import com.baseball.game.dto.MemberDto;

public interface MemberService {
    MemberDto register(MemberDto memberDto) throws Exception;
    boolean checkLogin(String id, String pw);
    String getUserNameById(String id);
}
