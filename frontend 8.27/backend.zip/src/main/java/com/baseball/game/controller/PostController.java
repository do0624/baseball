package com.baseball.game.controller;

import com.baseball.game.dto.PostDto;
import com.baseball.game.service.PostService;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/post")  // 기존 /api/board → /api/post
public class PostController {
    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public Map<String, Object> getPosts(
            @RequestParam(defaultValue = "all") String category,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        return postService.getPosts(category, keyword, page, size);
    }

    @GetMapping("/{id}")
    public PostDto getPost(@PathVariable("id") int postId) {
        return postService.getPost(postId);
    }

    @PostMapping
    public void createPost(@RequestBody PostDto post) {
        postService.createPost(post);
    }

    @PutMapping("/{id}")
    public void updatePost(@PathVariable("id") int postId, @RequestBody PostDto post) {
        post.setPostId(postId);
        postService.updatePost(post);
    }

    @DeleteMapping("/{id}")
    public void deletePost(@PathVariable("id") int postId) {
        postService.deletePost(postId);
    }
}
