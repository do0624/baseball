package com.baseball.game.service;

import com.baseball.game.dto.CommentDto;
import com.baseball.game.mapper.CommentMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommentService {

    private final CommentMapper commentMapper;

    public CommentService(CommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }

    public List<CommentDto> getCommentsByPostId(int postId) {
        return commentMapper.getCommentsByPostId(postId);
    }

    public void createComment(CommentDto comment) {
        commentMapper.insertComment(comment);
    }

    public void deleteComment(int commentId) {
        commentMapper.deleteComment(commentId);
    }
}
