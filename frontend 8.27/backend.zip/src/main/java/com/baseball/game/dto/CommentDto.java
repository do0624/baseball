package com.baseball.game.dto;

import java.time.LocalDateTime;

public class CommentDto {
    private Integer commentId;
    private Integer postId;
    private Integer userId; // 로그인 사용자 ID, 익명 가능
    private String content;
    private LocalDateTime createdAt;

    // getters & setters
    public Integer getCommentId() { return commentId; }
    public void setCommentId(Integer commentId) { this.commentId = commentId; }

    public Integer getPostId() { return postId; }
    public void setPostId(Integer postId) { this.postId = postId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
